package com.main.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.main.model.Admin;
import com.main.model.Teacher;
import com.main.service.TeacherService;

 

@Controller
public class AdminController {

 

    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    
    @Autowired
    private TeacherService teacherservice;
    
    //To Teacher Login
    @RequestMapping(value = "/adminLogin")
    public String adminLogin(ModelMap model) {
        model.addAttribute("adminform", new Admin());
        return "AdminLogin";
    }
   
    //Authenticate Teacher
    @RequestMapping(value="/authenticateAdmin", method= RequestMethod.POST)
    public String authenticateUser(@ModelAttribute("adminform") Admin admin1,
            ModelMap model) {
        String msg=" ";
        String view=null;
        int i=0;
        List<Admin> list=teacherservice.fetchAdminList();
        for(Admin admin:list)
        {
            if(admin.getAdminId().equals(admin1.getAdminId()) && admin.getPassword().equals(admin1.getPassword()))
            {
                i++;               
                view="AdminHome";
            }
        }
        if(i==0){
            msg="Invalid Credentials!!Please Check";
            System.out.println(msg);
            view="AdminLogin";
            model.addAttribute("msg",msg);
            System.out.println("Not found");
        }
        return view;
    }

    
    @RequestMapping(value = "/addTeacher", method = RequestMethod.GET)
    public String addTeacher(ModelMap map) {
        Teacher teacher=new Teacher();
        map.addAttribute("teacherform",teacher);
        return "TeacherRegistration";
    }
    //Save Student details
    @RequestMapping(value = "/saveTeacher", method = RequestMethod.POST)
    public String saveTeacher(@Validated @ModelAttribute("TeacherRegistration") Teacher teacher,
            BindingResult result, ModelMap map) {
        String viewname;
        if (result.hasErrors()) {
            viewname = "TeacherRegistration";
        } else {
            teacherservice.saveTeacher(teacher);
            viewname = "AdminHome";
        }
        return viewname;
    }
}