package com.main.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name = "student")
public class Student {
	@Id
	@Column(name="Studentid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Studentid;
	
	@NotEmpty
	@Size(min = 6, max = 15)
	private String name;
	
	@NotEmpty
	@Size(min=6,max=20)
	private String password;
	
	@NotEmpty
	private String standard;
	
	
	@NotEmpty
	private String fatherName;
	
	@NotEmpty
	private String motherName;
	
	
	@NotEmpty
	private String dob;
	
	@NotEmpty
	@Email
	private String email;
	
	@NotNull
	@Min(9)
	//@Max(10)
	private Long phone;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(Integer studentid, String name, String password, String standard, String fatherName,
			String motherName, String dob, String email, Long phone) {
		super();
		Studentid = studentid;
		this.name = name;
		this.password = password;
		this.standard = standard;
		this.fatherName = fatherName;
		this.motherName = motherName;
		this.dob = dob;
		this.email = email;
		this.phone = phone;
	}
	public Student(String name, String password, String standard, String fatherName, String motherName,
			String dob, String email, Long phone) {
		super();
		this.name = name;
		this.password = password;
		this.standard = standard;
		this.fatherName = fatherName;
		this.motherName = motherName;
		this.dob = dob;
		this.email = email;
		this.phone = phone;
	}
	public int getStudentid() {
		return Studentid;
	}
	public void setStudentid(Integer studentid) {
		Studentid = studentid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getPhone() {
		return phone;
	}
	public void setPhone(Long phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Student [Studentid=" + Studentid + ", name=" + name + ", password=" + password + ", standard="
				+ standard + ", fatherName=" + fatherName + ", motherName=" + motherName
				+ ", dob=" + dob + ", email=" + email + ", phone=" + phone + "]";
	}
	
	
}
