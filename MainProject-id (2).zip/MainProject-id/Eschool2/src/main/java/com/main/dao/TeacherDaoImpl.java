package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Admin;
import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.Teacher;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;

/**
 * @author Rajesh Padmanabhuni
 * 
 *         This TeacherDao Will be providing the implementation for various
 *         database operations by using both SQL and HQL queries.
 */
@Repository
public class TeacherDaoImpl implements TeacherDao {

	private static Logger log = Logger.getLogger(TeacherDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;


	public void saveTimetable(TimeTable timetable) {
		sessionFactory.getCurrentSession().save(timetable);
	
		
	}

	
	public List<Teacher> fetchTeacherList() {
		List<Teacher> list  = sessionFactory.getCurrentSession().createQuery("from Teacher").list();
		return list;
	}

	
	public void saveEnotes(Enotes enotes) {
		sessionFactory.getCurrentSession().save(enotes);
		
		
	}

	
	public void saveFee(Fee fee) {
		sessionFactory.getCurrentSession().save(fee);
		
	}


	public List<TeacherFeedback> fetchFeedbackList(String teacherName) {
		System.out.println(teacherName);
		Query query = sessionFactory.getCurrentSession().createQuery("from TeacherFeedback T where T.name=:ename");
		query.setParameter("ename",teacherName);
		List<TeacherFeedback> list = query.list();
		return list;
	}


	public void saveFeedback(StudentFeedback studentFeedback) {
		// TODO Auto-generated method stub
		log.info("Inside saveFeedback Method of Dao layer");
		sessionFactory.getCurrentSession().save(studentFeedback);
	}


	public void saveTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(teacher);
		
	}


	public List<Admin> fetchAdminList() {
		// TODO Auto-generated method stub
		List<Admin> list  = sessionFactory.getCurrentSession().createQuery("from Admin").list();
        return list;
	}

	
}