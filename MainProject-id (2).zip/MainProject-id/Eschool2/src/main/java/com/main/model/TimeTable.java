package com.main.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name = "timetable")
public class TimeTable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer TimeTableId;
	@NotEmpty
	@Size(min = 6, max = 15)
	private String standard;
	@NotEmpty
	private String timeSlot;
	@NotEmpty
	private String teacher;
	@NotEmpty
	private String subject;
	@NotEmpty
	private String meetingLink;
	@NotEmpty
	private String meetingDate;
	
	public TimeTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TimeTable(Integer timeTableId, String standard, String timeSlot, String teacher, String subject,
			String meetingLink, String meetingDate) {
		super();
		TimeTableId = timeTableId;
		this.standard = standard;
		this.timeSlot = timeSlot;
		this.teacher = teacher;
		this.subject = subject;
		this.meetingLink = meetingLink;
		this.meetingDate = meetingDate;
	}
	public TimeTable(String standard, String timeSlot, String teacher, String subject, String meetingLink,
			String meetingDate) {
		super();
		this.standard = standard;
		this.timeSlot = timeSlot;
		this.teacher = teacher;
		this.subject = subject;
		this.meetingLink = meetingLink;
		this.meetingDate = meetingDate;
	}
	public Integer getTimeTableId() {
		return TimeTableId;
	}
	public void setTimeTableId(Integer timeTableId) {
		TimeTableId = timeTableId;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMeetingLink() {
		return meetingLink;
	}
	public void setMeetingLink(String meetingLink) {
		this.meetingLink = meetingLink;
	}
	public String getMeetingDate() {
		return meetingDate;
	}
	public void setMeetingDate(String meetingDate) {
		this.meetingDate = meetingDate;
	}
	@Override
	public String toString() {
		return "TimeTable [TimeTableId=" + TimeTableId + ", standard=" + standard + ", timeSlot=" + timeSlot
				+ ", teacher=" + teacher + ", subject=" + subject + ", meetingLink=" + meetingLink + ", meetingDate="
				+ meetingDate + "]";
	}
	
	
}
