
package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "studentFeedback")
public class StudentFeedback {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer FeedbackId;
	
	private int studentId;
	private String feedback;
	
	public StudentFeedback()
	{
		
	}

	public StudentFeedback(Integer feedbackId, int studentId, String feedback) {
		super();
		FeedbackId = feedbackId;
		this.studentId = studentId;
		this.feedback = feedback;
	}

	public StudentFeedback(int studentId, String feedback) {
		super();
		this.studentId = studentId;
		this.feedback = feedback;
	}

	public Integer getFeedbackId() {
		return FeedbackId;
	}

	public void setFeedbackId(Integer feedbackId) {
		FeedbackId = feedbackId;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	
}
