package com.main.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.Teacher;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;
import com.main.service.StudentService;
import com.main.service.TeacherService;


@Controller
public class TeacherController {

	private static final Logger log = LoggerFactory.getLogger(TeacherController.class);
	
	@Autowired
	private StudentService studentservice;
	
	@Autowired
	private StudentService studentservice1;
	
	@Autowired
	private TeacherService teacherservice;
	
	Teacher CurrentTeacher;
	
			//To home page
			@RequestMapping(value = "/home")
			public String home() {
				log.info("Inside Home");
				return "HomePage";
			}
			
			//To teacherhome page
			@RequestMapping(value = "/TeacherHome")
			public String teacherhome() {
				log.info("Inside Home");
				return "TeacherHome";
			}
	
			//To selectStandard page
			@RequestMapping(value = "/standardSelect", method = RequestMethod.GET)
			public String standardSelect() {
				log.info("Inside standardSelect");
				return "standardSelect";
			}
			
			String selectedStandard=null;
			
			@RequestMapping(value="/selected/{standard}")
			public String test(@PathVariable("standard") String stand) {
			System.out.println(stand);
			selectedStandard=stand;
			return "viewDetails";
			}
			
			
			//To selectID page
			@RequestMapping(value = "/teacherCheckFee", method = RequestMethod.GET)
			public String selectID(ModelMap map) {
				log.info("Inside selectID");
				Student student=new Student();
				map.addAttribute("studentid",student);
				return "selectID";
			}
			
			@RequestMapping(value="/selectedid")
			public String test(@ModelAttribute("studentform") Student student, ModelMap map) {
			System.out.println(student.getStudentid());
			List<Fee> feelist= studentservice.fetchFeeList(student.getStudentid());
			System.out.println(feelist);
			map.addAttribute("feelist", feelist);
			return "FeeDetails";
			}
			
			//Display timetable details
			@RequestMapping(value = "/teacherDisplayTimeTable")
			public String fetchTimeTable(ModelMap map) {
				List<TimeTable> timetablelist = studentservice.fetchTimeTableList(selectedStandard);
				map.addAttribute("timetablelist", timetablelist);
				return "DisplayTimeTable";
			}
			
			//Display Enotes details
			@RequestMapping(value = "/teacherDisplayEnotes")
			public String fetchEnotes(ModelMap map) {
				List<Enotes> enoteslist = studentservice.fetchEnotesList(selectedStandard);
				map.addAttribute("enoteslist", enoteslist);
				return "DisplayENotes";
			}
			
	        //To update Fee
			@RequestMapping(value = "/addFee", method = RequestMethod.GET)
			public String addFee(ModelMap map) {
				log.info("Inside addTimeTable method in controller class");
				Fee fee=new Fee();
				map.addAttribute("feeform",fee);
				return "UpdateFee";
			}
			
			//Save Fee details
			@RequestMapping(value = "/saveFee", method = RequestMethod.POST)
			public String saveFee(@Validated @ModelAttribute("feeform") Fee fee,
					BindingResult result, ModelMap map) {
				log.info("Inside saveFee Method");
				String viewname;
				if (result.hasErrors()) {
					log.info("Error while Passing TimeTable Details to Service layer from Controller");
					viewname = "UpdateFee";
				} else {
					log.info("Passing TimeTable Details to Service layer from Controller");
					teacherservice.saveFee(fee);
					viewname = "AdminHome";
				}
				return viewname;
			}
		
	//To update Enotes
		@RequestMapping(value = "/addEnotes", method = RequestMethod.GET)
		public String addEnotes(ModelMap map) {
			log.info("Inside addTimeTable method in controller class");
			Enotes enotes=new Enotes();
			map.addAttribute("enotesform",enotes);
			return "UpdateENotes";
		}
		
		//Save Enotes
		@RequestMapping(value = "/saveEnotes", method = RequestMethod.POST)
		public String saveEnotes(@Validated @ModelAttribute("enotesform") Enotes enotes,
				BindingResult result, ModelMap map) {
			log.info("Inside saveTimeTable Method");
			String viewname;
			if (result.hasErrors()) {
				log.info("Error while Passing TimeTable Details to Service layer from Controller");
				viewname = "UpdateENotes";
			} else {
				log.info("Passing TimeTable Details to Service layer from Controller");
				teacherservice.saveEnotes(enotes);
				viewname = "TeacherHome";
			}
			return viewname;
		}
	
	//To Teacher Login
	@RequestMapping(value = "/teacherLogin")
	public String viewteacher(ModelMap model) {
		model.addAttribute("teacher", new Teacher());
		return "TeacherLogin";
	}
	
	//Authenticate Teacher
	@RequestMapping(value="/authenticateTeacher", method= RequestMethod.POST)
	public String authenticateUser(@ModelAttribute("teacher") Teacher user,
			ModelMap model) {
		String msg=" ";
		String view=null;
		int i=0;
		List<Teacher> list=teacherservice.fetchTeacherList();
		for(Teacher tchr:list)
		{
			if(user.getTeacherId().equals(tchr.getTeacherId()) && user.getPassword().equals(tchr.getPassword()))
			{
				i++;
				CurrentTeacher=tchr;
				System.out.println(CurrentTeacher);
				
				view="TeacherHome";
			}
		}
		if(i==0){
			msg="Invalid Credentials!!Please Check";
			System.out.println(msg);
			view="TeacherLogin";
			model.addAttribute("msg",msg);
			System.out.println("Not foound");
		}
		return view;
	}
	
	//To update Time Table
	@RequestMapping(value = "/addTimeTable", method = RequestMethod.GET)
	public String addTimeTable(ModelMap map) {
		log.info("Inside addTimeTable method in controller class");
		TimeTable timetable=new TimeTable();
		map.addAttribute("timetableform",timetable);
		return "UpdateTimeTable";
	}
	
	//Save time table details
	@RequestMapping(value = "/saveTimeTable", method = RequestMethod.POST)
	public String saveTimeTable(@Validated @ModelAttribute("timetableform") TimeTable timetable,
			BindingResult result, ModelMap map) {
		log.info("Inside saveTimeTable Method");
		String viewname;
		if (result.hasErrors()) {
			log.info("Error while Passing TimeTable Details to Service layer from Controller");
			viewname = "UpdateTimeTable";
		} else {
			log.info("Passing TimeTable Details to Service layer from Controller");
			teacherservice.saveTimetable(timetable);
			viewname = "TeacherHome";
		}
		return viewname;
	}
	
	
	
	//To update Student details
	@RequestMapping(value = "/addStudent", method = RequestMethod.GET)
	public String addStudent(ModelMap map) {
		log.info("Inside addStudent method in controller class");
		Student student=new Student();
		map.addAttribute("listStudents", this.studentservice.fetchStudentList());
		System.out.println(this.studentservice.fetchStudentList());
		map.addAttribute("studentform",student);
		return "StudentRegistration";
	}
	
	//Save Student details
	@RequestMapping(value = "/saveStudent", method = RequestMethod.POST)
	public String saveStudent(@Validated @ModelAttribute("studentform") Student student,
			BindingResult result, ModelMap map) {
		log.info("Inside saveStudent Method");
		String viewname;
		if (result.hasErrors()) {
			log.info("Error while Passing Student Details to Service layer from Controller");
			viewname = "StudentRegistration";
		} else {
			log.info("Passing Student Details to Service layer from Controller");
			
			if(student.getStudentid() == 0){
				//new person, add it
				this.studentservice1.saveStudent(student);
			}else{
				//existing person, call update
				this.studentservice1.updateStudent(student);
			}
			viewname = "StudentRegistration";
		}
		return viewname;
	}
		
	
	//remove student
	@RequestMapping("/remove/{Studentid}")
    public String removePerson(@PathVariable("Studentid") int Studentid){
		
		this.studentservice1.removeStudent(Studentid);
        return "TeacherHome";
    }
 
	//update student
    @RequestMapping("/edit/{Studentid}")
    public String editPerson(@PathVariable("Studentid") int Studentid, Model model){
    	System.out.println(Studentid);
        model.addAttribute("studentform", this.studentservice1.getStudentById(Studentid));
        System.out.println( this.studentservice1.getStudentById(Studentid));
        model.addAttribute("listStudents", this.studentservice1.fetchStudentList());
        return "StudentRegistration";
    }
	
	
	
	
	
	//Logout teacher
	@RequestMapping("/teacherlogout")
	public String logout(HttpServletRequest request)
	{
		request.getSession().invalidate();
		return "HomePage";
	}
	
	// Displaying MyFeedback details
		@RequestMapping(value = "/myFeedback")
		public String FeedbackDetails(ModelMap map) {			
			List<TeacherFeedback> feedbacklist = teacherservice.fetchFeedbackList(CurrentTeacher.getTeacherName());
			map.addAttribute("feedbacklist", feedbacklist);
			return "DisplayTeacherFeedback";
		}
		//Feedback
		@RequestMapping(value = "/StudentFeedback", method = RequestMethod.GET)
		public String Feedback(ModelMap map) {
			log.info("Inside TeacherFeedback");
			StudentFeedback studentFeedback=new StudentFeedback();
			map.addAttribute("studentfeedbackform",studentFeedback);
			return "StudentFeedback";
		}
		
		//Save Feedback
		@RequestMapping(value = "/saveStudentFeedback", method = RequestMethod.POST)
		public String saveFeedback(@Validated @ModelAttribute("studentfeedbackform") StudentFeedback studentFeedback,
				BindingResult result, ModelMap map) {
			log.info("Inside saveStudentFeedback Method");
			String viewname;
			if (result.hasErrors()) {
				log.info("Error while Passing StudentFeedback Details to Service layer from Controller");
				viewname = "StudentFeedback";
			} else {
				log.info("Passing StudentFeedback Details to Service layer from Controller");
				teacherservice.StudentFeedback(studentFeedback);
				viewname = "TeacherHome";
			}
			return viewname;
		}
	
	@ModelAttribute
	public void headerMessage(Model model){
		List<String> standardList = new ArrayList<String>();
		standardList.add("Class-I");
		standardList.add("Class-II");
		standardList.add("Class-III");
		standardList.add("Class-IV");
		standardList.add("Class-V");
		standardList.add("Class-VI");
		standardList.add("Class-VII");
		standardList.add("Class-VIII");
		standardList.add("Class-IX");
		standardList.add("Class-X");
		standardList.add("Class-XI");
		standardList.add("Class-XII");
		
		List<String> subjectList = new ArrayList<String>();
		subjectList.add("Telugu");
		subjectList.add("Hindi");
		subjectList.add("English");
		subjectList.add("Mathematics");
		subjectList.add("Science");
		subjectList.add("Social");
		subjectList.add("General Knowledge");
		subjectList.add("Computers");
		
		
		//List<String> studentIdList=studentservice.
		
		
		
		model.addAttribute("standardList", standardList);
		model.addAttribute("subjectList", subjectList);

		
	}
	
}
