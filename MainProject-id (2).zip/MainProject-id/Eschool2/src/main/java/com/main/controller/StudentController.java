package com.main.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.main.model.Enotes;

import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;
import com.main.service.StudentService;
import com.main.service.TeacherService;

@Controller
public class StudentController {

	private static final Logger log = LoggerFactory.getLogger(StudentController.class);



	@Autowired
	private StudentService studentservice;

	@Autowired
	private TeacherService teacherservice;

	Student CurrentStudent;

	
	//To studenthome page
	@RequestMapping(value = "/StudentHome")
	public String teacherhome() {
		log.info("Inside Home");
		return "StudentHome";
	}
	
	//Getting into Student login
	@RequestMapping(value = "/studentLogin")
	public String view2(ModelMap model) {
		model.addAttribute("student", new Student());
		return "StudentLogin";
	}
	
	//Feedback
	@RequestMapping(value = "/Feedback", method = RequestMethod.GET)
	public String Feedback(ModelMap map) {
		log.info("Inside TeacherFeedback");
		TeacherFeedback teacherFeedback=new TeacherFeedback();
		map.addAttribute("teacherfeedbackform",teacherFeedback);
		return "TeacherFeedback";
	}
	
	//Save Feedback
	@RequestMapping(value = "/saveFeedback", method = RequestMethod.POST)
	public String saveFeedback(@Validated @ModelAttribute("teacherfeedbackform") TeacherFeedback teacherFeedback,
			BindingResult result, ModelMap map) {
		log.info("Inside saveTeacherFeedback Method");
		String viewname;
		if (result.hasErrors()) {
			log.info("Error while Passing TeacherFeedback Details to Service layer from Controller");
			viewname = "TeacherFeedback";
		} else {
			log.info("Passing TeacherFeedback Details to Service layer from Controller");
			System.out.println(teacherFeedback);
			studentservice.TeacherFeedback(teacherFeedback);
			viewname = "TeacherHome";
		}
		return viewname;
	}
	
	//Authenticating Student
	@RequestMapping(value = "/authenticateStudent", method = RequestMethod.POST)
	public String authenticateUser(@ModelAttribute("student") Student user, Model model) {
		int i=0;
		String msg="";
		List<Student> list = studentservice.fetchStudentList();
		for (Student stud : list) {
			if ((user.getStudentid()==stud.getStudentid()) && user.getPassword().equals(stud.getPassword())) {
				i++;
				CurrentStudent = stud;
				System.out.println(CurrentStudent);
				return "StudentHome";
			}
			
		}
		if(i==0){
			
			msg="Invalid Credentials!!Please Check";
		}
		model.addAttribute("msg",msg);
		System.out.println("Not found");
		return "StudentLogin";
	}
	
	//Display timetable details
	@RequestMapping(value = "/displayTimeTable")
	public String fetchTimeTable(ModelMap map) {
		List<TimeTable> timetablelist = studentservice.fetchTimeTableList(CurrentStudent.getStandard());
		map.addAttribute("timetablelist", timetablelist);
		return "DisplayTimeTable";
	}

	// Displaying Student details
	@RequestMapping(value = "/myDetails")
	public String Studentdetails(ModelMap map) {
		System.out.println(CurrentStudent);
		map.addAttribute("myDetails", CurrentStudent);
		return "StudentDetails";
	}
	
	//Display Enotes details
	@RequestMapping(value = "/displayEnotes")
	public String fetchEnotes(ModelMap map) {
		List<Enotes> enoteslist = studentservice.fetchEnotesList(CurrentStudent.getStandard());
		map.addAttribute("enoteslist", enoteslist);
		return "DisplayENotes";
	}

	// Displaying Fee details
	@RequestMapping(value = "/myFee")
	public String feedetails(ModelMap map) {
		List<Fee> feelist= studentservice.fetchFeeList(CurrentStudent.getStudentid());
		System.out.println(feelist);
		map.addAttribute("feelist", feelist);
		return "FeeDetails";
	}
	
	// logout
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		HttpSession session=request.getSession();
		session.invalidate();
		return "HomePage";
	}
	@RequestMapping("/studenthome")
	public String home() {
		return "StudentHome";
	}
	// Displaying MyFeedback details
			@RequestMapping(value = "/myFeedbacks")
			public String FeedbackDetails(ModelMap map) {			
				List<StudentFeedback> feedbacklist = studentservice.fetchFeedbackList(CurrentStudent.getStudentid());
				map.addAttribute("feedbacklist", feedbacklist);
				return "DisplayStudentFeedback";
			}
}
