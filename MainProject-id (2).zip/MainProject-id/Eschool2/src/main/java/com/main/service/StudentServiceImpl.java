package com.main.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.StudentDao;
import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.Teacher;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

	private static Logger log = Logger.getLogger(StudentServiceImpl.class);
	@Autowired
	private StudentDao studentdao;


	
	public void saveStudent(Student student) {
		log.info("Passing Student Information to Dao Layer from Service Layer");
		studentdao.saveStudent(student);
		
	}


	
	public List<Student> fetchStudentList() {
		log.info("Inside fetchStudentList Method of Dao layer");
		List<Student> list  = studentdao.fetchStudentList();
		return list;
	}


	
	public List<TimeTable> fetchTimeTableList(String standard) {
		List<TimeTable> list  = studentdao.fetchTimeTableList(standard);
		return list;
	}
	

	
	public List<Enotes> fetchEnotesList(String standard) {
		List<Enotes> list  = studentdao.fetchEnotesList(standard);
		return list;
	}
	
	
	public List<Fee> fetchFeeList(Integer studentId) {
		List<Fee> feelist  = studentdao.fetchFeeList(studentId);
		return feelist;
	}



	public void TeacherFeedback(com.main.model.TeacherFeedback teacherFeedback) {
		// TODO Auto-generated method stub
		studentdao.saveFeedback(teacherFeedback);
	}



	public List<StudentFeedback> fetchFeedbackList(Integer studentid) {
		
		List<StudentFeedback> feedbacklist  = studentdao.fetchFeedbackList(studentid);
		return feedbacklist;
	}



	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		studentdao.updateStudent(student);
	}



	public void removeStudent(int studentid) {
		// TODO Auto-generated method stub
		studentdao.removeStudent(studentid);
	}



	public Student getStudentById(int studentid) {
		// TODO Auto-generated method stub
		return studentdao.getStudentById(studentid);
	}
}
